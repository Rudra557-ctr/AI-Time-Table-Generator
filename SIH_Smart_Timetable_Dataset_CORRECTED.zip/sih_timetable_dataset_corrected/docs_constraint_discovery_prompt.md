# SIH Smart Timetable — Constraint Discovery Prompt

You are an Operations Research / CP-SAT expert helping design a university-wide timetable generator.

Use the attached SIH problem statement and the synthetic dataset/schema. Do NOT write implementation code yet.

We have:
- 4 academic years
- 4 branches: CSE, ECE, AIML, AR
- 16 sections
- 1000 students
- 40 faculty
- multiple courses and course offerings
- multiple faculty members can be eligible to teach the same course
- a faculty member can teach multiple courses and multiple years/branches
- rooms, lecture halls, computer labs, physics/electronics/robotics labs, and workshops
- faculty slot availability and preferences
- room slot availability
- individual student enrollments
- OAE/PCE elective groups
- interdisciplinary and skill courses
- fixed institutional events
- multi-slot laboratory/workshop sessions

IMPORTANT MODELING RULE:
Do NOT assume one course has one professor. Faculty assignment may be a decision variable when multiple eligible faculty exist. A fixed faculty assignment may also exist in a future version.

Your task:
1. Identify every candidate hard, soft, and conditional constraint.
2. For every constraint explain:
   - ID
   - classification
   - exact rule
   - why it exists
   - required data fields
   - entities involved
   - whether it is explicitly required, strongly implied, common practice, optional preference, or needs university confirmation
3. Pay special attention to:
   - faculty collisions across different years/branches
   - room collisions
   - section collisions
   - student-level elective collisions
   - faculty eligibility
   - faculty availability
   - room availability
   - room capacity/type/equipment
   - labs and consecutive periods
   - shared/interdisciplinary courses
   - OAE/PCE synchronization
   - fixed events
   - workload limits
   - infeasibility
   - timetable regeneration/modification
4. Separate validity constraints from optimization preferences.
5. Identify constraints that may conflict and explain how infeasibility should be handled.
6. Give a mathematical CP-SAT formulation for every major hard constraint.
7. Propose a configurable weighted objective for soft constraints; do not claim arbitrary weights are official.
8. Produce final tables:
   A. Hard constraints
   B. Soft constraints
   C. Conditional constraints
   D. Required dataset fields
   E. Infeasibility sources
   F. Objective hierarchy

Do not silently turn a preference into a hard constraint. Clearly label assumptions.
