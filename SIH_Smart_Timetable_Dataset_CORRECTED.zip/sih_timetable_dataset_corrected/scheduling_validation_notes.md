# Scheduling-level validation notes

The original generated dataset had two semantic issues that have now been corrected:

1. Specialized labs/workshops did not have enough compatible capacity/resources for the largest sections.
   - Lab capacities were increased to 70.
   - Two engineering workshop rooms were added.
2. Elective offering student_count was initially using total university course enrollment.
   - It is now calculated per section + elective course.
   - Zero-demand elective offerings are removed because they do not need scheduling for that section.

The main dataset should now be treated as the corrected baseline for constraint design.
