# SIH Smart Timetable — Corrected Synthetic Dataset

This is a synthetic development dataset for the SIH timetable optimization project.

Scale:
- 1000 students
- 40 faculty
- 4 years
- 4 branches
- 16 sections
- 65 courses
- 144 course offerings
- 29 rooms/resources
- 35 teaching slots/week
- 6 elective groups

Important modeling choices:
- A course can have multiple eligible faculty members.
- A faculty member can teach multiple courses and multiple years/branches.
- Faculty eligibility is separate from course offerings.
- Student-level OAE/PCE enrollments are included.
- Lab/workshop requirements include compatible resource types.
- Faculty and room availability are slot-level.
- Faculty preferences are separate from availability.
- Elective offering student counts are corrected to actual enrollment demand.

This dataset is synthetic and must not be presented as official university data.
